import React from "react";
import { NavLink } from "react-router-dom";
function Header() {
  return (
    <section className="menu">
      <div className="title">
        <h2> Our menu</h2>
        <div className=" underline"></div>
      </div>
      <div className="btn-container">
        <NavLink to="/" className="filter-btn">
          All{" "}
        </NavLink>
        <NavLink to="/breakfast" className="filter-btn">
          Breakfast{" "}
        </NavLink>
        <NavLink to="/lanch" className="filter-btn">
          Lanch{" "}
        </NavLink>
        <NavLink to="/shakes" className="filter-btn">
          Shets{" "}
        </NavLink>
      </div>
    </section>
  );
}

export default Header;
