import { useState } from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import AllMenu from "./pages/AllMenu";
import Breakfast from "./pages/Breakfast";
import Lanch from "./pages/Lanch";
import Shakes from "./pages/Shakes";

function App() {
  return (
    <Router>
      <Header/>
      <Routes>
        <Route path="/" element={<AllMenu/>} />
        <Route path="/Breakfast" element={<Breakfast/>} />
        <Route path="/Lanch" element={<Lanch/>} />
        <Route path="/Shakes" element={<Shakes/>} />
      </Routes>
    </Router>
  );
}

export default App;
