import { useState } from 'react'
import React from 'react'
import {useFetch} from '../hooks/useFetch'
function Breakfast() {
    const [url, setUrl] = useState('http://localhost:3000/menu?category=breakfast')
    const {data  , error , isPending} = useFetch(url)

  return (
    <div className="section-center">
    {data && data.map((item)=>{
      // const {id, title, category, price, desc} = item
      return (
        <article className="menu-item" key={item.id}>
        <img className="photo" src={item.img} alt="title" />
        <div className="item-info">
          <header>
            <h5>{item.title}</h5>
            <span className="item-price">{item.price}</span>
          </header>
          <p className="item-text">{item.desc}</p>
        </div>
      </article>
      )
    })}
  </div>
  )
}

export default Breakfast

