import React from "react";
import { useFetch } from "../hooks/useFetch";
function AllMenu() {
  const { data, isPending, error } = useFetch(
    "http://localhost:3000/menu"
  );
  console.log(data);
  return (
    <div className="section-center">
    {data && data.map((item)=>{
      // const {id, title, category, price, desc} = item
      return (
        <article className="menu-item" key={item.id}>
        <img className="photo" src={item.img} alt="title" />
        <div className="item-info">
          <header>
            <h5>{item.title}</h5>
            <span className="item-price">{item.price}</span>
          </header>
          <p className="item-text">{item.desc}</p>
        </div>
      </article>
      )
    })}
  </div>
  )
}

export default AllMenu;
